#!/usr/bin/env python3
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
from compose_sticker import ROOT,DATA,filename,FONT

def sheet(items,path,columns=5):
    cellw,cellh=444,440
    rows=(len(items)+columns-1)//columns
    out=Image.new('RGB',(columns*cellw,rows*cellh),'#f4f5f8')
    d=ImageDraw.Draw(out);f=ImageFont.truetype(str(FONT),23)
    for k,item in enumerate(items):
        x=k%columns*cellw;y=k//columns*cellh
        d.rounded_rectangle((x+10,y+10,x+cellw-10,y+cellh-10),radius=20,fill='white')
        d.text((x+24,y+20),f'No.{item["no"]:02}',font=f,fill='#70477f')
        p=ROOT/'output/stickers'/filename(item)
        if p.exists():
            im=Image.open(p).convert('RGBA');im.thumbnail((404,350))
            out.paste(im,(x+(cellw-im.width)//2,y+67),im)
        else:d.text((x+24,y+160),'制作中',font=f,fill='#999999')
    out.save(path,optimize=True)

if __name__=='__main__':
    sheet(DATA,ROOT/'output/contact-sheets/all-40.png')
    for start in range(0,40,10):sheet(DATA[start:start+10],ROOT/f'output/contact-sheets/group-{start//10+1}.png')
