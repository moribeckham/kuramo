#!/usr/bin/env python3
"""Mechanical checks only. Visual scoring is separately recorded, never inferred."""
from pathlib import Path
import json,csv,hashlib,re
import xml.etree.ElementTree as ET
from PIL import Image
from compose_sticker import ROOT,DATA,filename

brief=(ROOT/'assets/production-brief.md').read_text()
original_mains=re.findall(r'【メイン文字】\n([^\n]+)',brief)
assert len(original_mains)==40

def check(item):
    path=ROOT/'output/stickers'/filename(item)
    if not path.exists():return {'No':item['no'],'main':item['main'],'status':'未生成'}
    im=Image.open(path)
    alpha=im.getchannel('A') if im.mode=='RGBA' else None
    bbox=alpha.point(lambda x:255 if x>8 else 0).getbbox() if alpha else None
    margin=min(bbox[0],bbox[1],370-bbox[2],320-bbox[3]) if bbox else 0
    svg=ET.parse(ROOT/f'working/text-svg/No{item["no"]:02}.svg')
    texts={el.get('data-role'):el.text for el in svg.iter('{http://www.w3.org/2000/svg}text') if el.get('data-role') in ('main','sub')}
    ok=texts=={'main':original_mains[item['no']-1],'sub':item['sub']} and item['main']==original_mains[item['no']-1]
    special= item['no']!=39 or texts['sub']=='（まじかよ…）'
    flags=[im.format=='PNG',im.mode=='RGBA',im.size==(370,320),path.stat().st_size<1024*1024,alpha is not None and alpha.getextrema()==(0,255),margin>=9,ok,special]
    return {'No':item['no'],'main':item['main'],'status':'PASS' if all(flags) else 'FAIL','size':str(im.size),'mode':im.mode,'bytes':path.stat().st_size,'margin_px':margin,'text_exact':ok,'No39_rule':special,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

if __name__=='__main__':
    rows=[check(x) for x in DATA]
    fields=list(dict.fromkeys(k for row in rows for k in row))
    with (ROOT/'reports/technical-checks.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    print(json.dumps({'pass':sum(r['status']=='PASS' for r in rows),'fail':[r for r in rows if r['status']=='FAIL'],'unmade':sum(r['status']=='未生成' for r in rows)},ensure_ascii=False,indent=2))
