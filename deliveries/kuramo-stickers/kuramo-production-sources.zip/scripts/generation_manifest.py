#!/usr/bin/env python3
"""Print independent image-generation jobs for the chat's image_gen tool.

This intentionally does not invent an HTTP endpoint or use a paid external API.
Use the supplied tool once per pending item and save the returned PNG path.
"""
from pathlib import Path
import json
from compose_sticker import ROOT,DATA

for item in DATA:
    no=item['no'];output=ROOT/f'working/illustrations/No{no:02}.png'
    if output.exists():continue
    prompt_file=ROOT/f'prompts/No{no:02}-v2-generation.txt'
    print(json.dumps({'no':no,'tool':'image_gen.imagegen','transparent_background':True,
                      'referenced_image_paths':[str(ROOT/'assets/reference/kuramo-kun-style-reference-v2.png')],
                      'prompt_file':str(prompt_file),'prompt_exists':prompt_file.exists(),'output':str(output)},ensure_ascii=False))
