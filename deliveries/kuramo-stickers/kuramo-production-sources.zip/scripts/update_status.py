#!/usr/bin/env python3
import csv,json
from compose_sticker import ROOT,DATA,filename
from quality_check import check

reviews_file=ROOT/'reports/visual-reviews.json'
reviews=json.loads(reviews_file.read_text()) if reviews_file.exists() else {}
status=[];quality=[]
for item in DATA:
    n=item['no'];r=reviews.get(str(n),{});t=check(item)
    scores=r.get('scores',[])
    total=sum(scores) if scores else ''
    accepted=bool(total and total>=90 and t['status']=='PASS' and r.get('character_ok'))
    exists=(ROOT/f'working/illustrations/No{n:02}.png').exists()
    status.append([n,item['main'],'完成' if accepted else ('検査中' if exists else '未着手'),
                   'OK' if t.get('text_exact') else '', 'OK' if r.get('character_ok') else '',
                   total,{1:2,2:2,3:2,4:1,5:1,6:1,7:1,13:1,20:2,21:1,22:1,36:1}.get(n,0),filename(item) if accepted else '',r.get('notes','')])
    quality.append([n,*scores,*(['']*(6-len(scores))),total,'合格' if accepted else '未完了',r.get('notes','')])
for name,header,rows in [
 ('production-status.csv',['No','メイン文字','生成状況','文字検査','キャラクター検査','品質点数','修正回数','ファイル名','備考'],status),
 ('quality-report.csv',['No','キャラクター25','テキスト20','構図20','整合性15','塗り10','視認性10','合計100','判定','目視所見'],quality)]:
    with (ROOT/'reports'/name).open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.writer(f);w.writerow(header);w.writerows(rows)
print('Complete:',sum(r[2]=='完成' for r in status),'/ 40')
