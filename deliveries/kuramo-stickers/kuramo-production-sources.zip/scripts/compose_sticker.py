#!/usr/bin/env python3
"""Compose approved text-free artwork and exact editable Japanese lettering.

No image-generation API is called. Original illustrations are never overwritten.
"""
from pathlib import Path
import argparse, json, re, math, html, shutil
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageOps
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from scipy.ndimage import binary_fill_holes, distance_transform_edt, binary_closing

ROOT = Path(__file__).resolve().parents[1]
SIZE = (1480,1280)
FONT = ROOT/'assets/MPLUSRounded1c-ExtraBold.ttf'
NAVY = '#202443'
DATA = json.loads((ROOT/'assets/stickers.json').read_text())
TT = TTFont(FONT)
CMAP = TT.getBestCmap()
GLYPHS = TT.getGlyphSet()
UNITS = TT['head'].unitsPerEm

def filename(item):
    return f"No{item['no']:02}_" + re.sub(r'[\\/:*?"<>|？]', '',item['main']) + '.png'

def line_width(text, size):
    return sum(TT['hmtx'][CMAP[ord(c)]][0] for c in text)/UNITS*size

def fit(text, preferred, width):
    missing = [c for c in text if ord(c) not in CMAP]
    if missing: raise ValueError(f'Unsupported glyphs: {missing}')
    return min(preferred, int(preferred*width/max(width,line_width(text,preferred))))

def add_line(layer, svg_lines, text, top, size, x=None, color=NAVY, stroke=12, role='effect',angle=0):
    width=line_width(text,size)
    x=(SIZE[0]-width)/2 if x is None else x
    font=ImageFont.truetype(str(FONT),size)
    # Pillow's left-top anchor gives exact editable placement, independent of glyph ascender.
    target=Image.new('RGBA',SIZE) if angle else layer
    draw=ImageDraw.Draw(target)
    draw.text((x,top),text,font=font,fill=color,stroke_width=stroke,
              stroke_fill='white',anchor='lt')
    if angle:
        target=target.rotate(angle,Image.Resampling.BICUBIC,center=(x+width/2,top+size/2))
        layer.alpha_composite(target)
    svg_lines.append(dict(text=text,x=round(x,2),y=top,size=size,color=color,stroke=stroke,role=role,angle=angle))

def write_svgs(item, lines):
    ident=f"No{item['no']:02}"
    header='<svg xmlns="http://www.w3.org/2000/svg" width="1480" height="1280" viewBox="0 0 1480 1280">'
    editable=[header,'<title>'+html.escape(item['main'])+'</title>']
    outlines=[header,'<title>'+html.escape(item['main'])+'</title>']
    for line in lines:
        t=line['text']; size=line['size']; x=line['x']; y=line['y']
        font=ImageFont.truetype(str(FONT),size)
        # SVG alphabetic baseline from Pillow's measured glyph box.
        top=font.getbbox(t,anchor='ls')[1]
        baseline=y-top
        angle=line.get('angle',0)
        if angle:
            transform=f'<g transform="rotate({-angle} {x+line_width(t,size)/2} {y+size/2})">'
            editable.append(transform);outlines.append(transform)
        editable.append(f'<text data-role="{line["role"]}" x="{x}" y="{baseline}" font-family="M PLUS Rounded 1c" font-weight="800" font-size="{size}" fill="{line["color"]}" stroke="white" stroke-width="{line["stroke"]*2}" stroke-linejoin="round" paint-order="stroke fill">{html.escape(t)}</text>')
        cursor=x
        for c in t:
            name=CMAP[ord(c)]; pen=SVGPathPen(GLYPHS); GLYPHS[name].draw(pen)
            d=pen.getCommands(); scale=size/UNITS
            outlines.append(f'<path d="{d}" transform="translate({cursor:.3f},{baseline}) scale({scale},-{scale})" fill="{line["color"]}" stroke="white" stroke-width="{line["stroke"]*2/scale:.3f}" stroke-linejoin="round" paint-order="stroke fill"/>')
            cursor+=TT['hmtx'][name][0]*scale
        if angle:editable.append('</g>');outlines.append('</g>')
    editable.append('</svg>'); outlines.append('</svg>')
    (ROOT/f'working/text-svg/{ident}.svg').write_text('\n'.join(editable))
    (ROOT/f'working/text-svg/{ident}-outlines.svg').write_text('\n'.join(outlines))
    (ROOT/f'working/text-svg/{ident}.json').write_text(json.dumps(lines,ensure_ascii=False,indent=2))

def compose(item):
    no=item['no']; source=ROOT/f'working/illustrations/No{no:02}.png'
    if not source.exists(): return None
    image=Image.open(source).convert('RGBA')
    # Exclude virtually invisible stray alpha pixels; preserve original source.
    alpha=image.getchannel('A').point(lambda x:0 if x<12 else x)
    image.putalpha(alpha)
    original_bbox=alpha.getbbox()
    image=image.crop(original_bbox)
    art=ImageOps.contain(image,(1320,780),Image.Resampling.LANCZOS)
    layer=Image.new('RGBA',SIZE)
    art_x=(1480-art.width)//2
    art_y=1200-art.height
    layer.alpha_composite(art,(art_x,art_y))
    lines=[]
    object_labels={9:('FAQ',448,802,83,15,'#fff2ce'),16:('LOGOUT',355,577,30,3,'white')}
    if no in object_labels:
        label,lx,ly,ls,angle,color=object_labels[no]
        scale=art.width/image.width
        cx=art_x+(lx-original_bbox[0])*scale
        cy=art_y+(ly-original_bbox[1])*scale
        label_size=int(ls*scale)
        add_line(layer,lines,label,cy-label_size/2,label_size,
                 x=cx-line_width(label,label_size)/2,color=color,stroke=0,role='object_label',angle=angle)
    main_size=fit(item['main'],150,1320)
    add_line(layer,lines,item['main'],86,main_size,stroke=16,role='main')
    sub_size=fit(item['sub'],65,1310)
    add_line(layer,lines,item['sub'],252,sub_size,stroke=10,role='sub')
    # Two short related effects; avoid duplicating the main/subtitle's message.
    omit=('✨','💦','？','？？','？？？','2STEP！') if no==20 else ('✨','💦','？','？？','？？？')
    effects=[t for t in item['effects'] if t not in omit][:2]
    if no in (33,35,38,40):effects=[item['effects'][0],item['effects'][2]]
    for i,t in enumerate(effects):
        sz=fit(t,62,605)
        x=94 if i==0 else 1386-line_width(t,sz)
        add_line(layer,lines,t,336 if i==0 else 345,sz,x=x,stroke=10)
    # One silhouette treatment, applied to the full combined scene, never per prop.
    a=np.asarray(layer.getchannel('A'))>24
    filled=binary_fill_holes(a)
    distance=distance_transform_edt(~filled)
    border=np.clip((18-distance)*255,0,255).astype('uint8')
    backing=Image.new('RGBA',SIZE,'white');backing.putalpha(Image.fromarray(border))
    shadow=Image.new('RGBA',SIZE,'#24223b')
    shadow.putalpha(Image.fromarray(border).filter(ImageFilter.GaussianBlur(7)).point(lambda x:int(x*.19)))
    out=Image.new('RGBA',SIZE)
    out.alpha_composite(shadow,(0,6))
    out.alpha_composite(backing)
    out.alpha_composite(layer)
    name=filename(item)
    out.save(ROOT/'output/masters'/name,dpi=(72,72),optimize=True)
    sale=out.resize((370,320),Image.Resampling.LANCZOS)
    sale.save(ROOT/'output/stickers'/name,dpi=(72,72),optimize=True)
    preview=Image.new('RGBA',SIZE,'#f2f3f6');preview.alpha_composite(out)
    preview.convert('RGB').save(ROOT/f'working/previews/No{no:02}.jpg',quality=92)
    write_svgs(item,lines)
    return name

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--no',type=int,nargs='*');args=ap.parse_args()
    for item in DATA:
        if args.no and item['no'] not in args.no:continue
        name=compose(item)
        if name:print(name)
