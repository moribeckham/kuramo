#!/usr/bin/env python3
"""Package only visually accepted, technically validated results."""
import json,shutil,zipfile,hashlib,csv
from pathlib import Path
from PIL import Image,ImageOps
from compose_sticker import ROOT,DATA,filename
from quality_check import check
from create_line_submission import build_submission
from create_store_images import build_store_images

reviews=json.loads((ROOT/'reports/visual-reviews.json').read_text())
for item in DATA:
    r=reviews.get(str(item['no']),{})
    assert r.get('character_ok') and sum(r.get('scores',[]))>=90, f'No{item["no"]}: visual review incomplete'
    assert check(item)['status']=='PASS',f'No{item["no"]}: technical check failed'

delivery=ROOT/'output/delivery'
pngs=delivery/'stickers';pngs.mkdir(parents=True,exist_ok=True)
for item in DATA:shutil.copy2(ROOT/'output/stickers'/filename(item),pngs/filename(item))

# Preserve the selected store images on every subsequent packaging run.
build_store_images()

# Explicit submission bundle, checked independently of the Canva/source archives.
build_submission()

shutil.copy2(ROOT/'output/contact-sheets/all-40.png',delivery/'all-40.png')
for f in (ROOT/'reports').iterdir():
    if f.is_file():shutil.copy2(f,delivery/f.name)
shutil.copy2(ROOT/'README.md',delivery/'README.md')
manifest=[]
for f in sorted(delivery.rglob('*')):
    if f.is_file() and f.name not in ('manifest.json',) and f.suffix!='.zip':
        manifest.append({'file':str(f.relative_to(delivery)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(delivery/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))

def archive(path,files,base):
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for f in files:
            if f.is_file():z.write(f,str(f.relative_to(base)))
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
    print(path.name,path.stat().st_size)

archive(delivery/'kuramo-40-stickers.zip',[p for p in delivery.rglob('*') if p.suffix!='.zip'],delivery)
upload=delivery/'line-upload-candidate.zip'
with zipfile.ZipFile(upload,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for item in DATA:z.write(ROOT/'output/stickers'/filename(item),f'{item["no"]:02}.png')
    for name in ['main.png','tab.png']:z.write(delivery/name,name)
with zipfile.ZipFile(upload) as z:assert len(z.namelist())==42 and z.testzip() is None
print(upload.name,upload.stat().st_size)
canva=delivery/'canva-editing-40.zip'
with zipfile.ZipFile(canva,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for item in DATA:z.write(ROOT/'output/masters'/filename(item),f'{item["no"]:02}.png')
with zipfile.ZipFile(canva) as z:assert len(z.namelist())==40 and z.testzip() is None
print(canva.name,canva.stat().st_size)
include=['assets','prompts','working/illustrations','working/text-svg','working/rejected','output/masters','output/contact-sheets','scripts','reports']
files=[ROOT/'README.md',ROOT/'requirements.txt']
for d in include:files.extend(p for p in (ROOT/d).rglob('*') if '__pycache__' not in p.parts)
archive(delivery/'kuramo-production-sources.zip',files,ROOT)
