#!/usr/bin/env python3
"""Build and inspect the static LINE submission ZIP from approved PNGs."""
from pathlib import Path
import hashlib
import io
import json
import shutil
import zipfile
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ZIP_NAME = 'LINE-submit-40-stickers.zip'


def inspect_png(name, data, expected_size):
    with Image.open(io.BytesIO(data)) as im:
        im.load()
        assert im.format == 'PNG', f'{name}: PNG required'
        assert im.size == expected_size, f'{name}: unexpected size {im.size}'
        assert im.mode == 'RGBA', f'{name}: RGBA required'
        assert data[24:26] == bytes([8, 6]), f'{name}: 8-bit RGBA PNG required'
        alpha = im.getchannel('A')
        assert alpha.getextrema() == (0, 255), f'{name}: transparency required'
        w, h = im.size
        edges = [(0, 0, w, 1), (0, h-1, w, h), (0, 0, 1, h), (w-1, 0, w, h)]
        assert all(alpha.crop(box).getextrema()[1] == 0 for box in edges), f'{name}: opaque canvas edge'
        assert len(data) < 1024*1024, f'{name}: exceeds 1 MiB'
        return {
            'file': name, 'width': w, 'height': h, 'format': 'PNG',
            'mode': im.mode, 'bit_depth': 8, 'alpha_range': [0, 255],
            'transparent_outer_edges': True, 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest(),
        }


def build_submission(root=ROOT):
    stage = root/'output/line-submission'
    stage.mkdir(parents=True, exist_ok=True)
    specs = {}
    for n in range(1, 41):
        sources = list((root/'output/stickers').glob(f'No{n:02}_*.png'))
        assert len(sources) == 1, f'Sticker {n}: expected one approved PNG, found {sources}'
        specs[f'{n:02}.png'] = (sources[0], (370, 320))
    specs['main.png'] = (root/'output/delivery/main.png', (240, 240))
    specs['tab.png'] = (root/'output/delivery/tab.png', (96, 74))
    for name, (source, size) in specs.items():
        inspect_png(name, source.read_bytes(), size)
        shutil.copy2(source, stage/name)

    target = root/'output/delivery'/ZIP_NAME
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name in specs:
            z.write(stage/name, name)

    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == 42 and set(z.namelist()) == set(specs)
        rows = [inspect_png(name, z.read(name), specs[name][1]) for name in z.namelist()]
        for row in rows:
            source = specs[row['file']][0]
            assert row['sha256'] == hashlib.sha256(source.read_bytes()).hexdigest()
    assert target.stat().st_size < 20*1024*1024
    report = {
        'archive': ZIP_NAME, 'bytes': target.stat().st_size,
        'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
        'sticker_count': 40, 'total_png_count': 42,
        'pngs_at_zip_root_only': True, 'archive_integrity': 'PASS',
        'specification_source': 'User supplied sizes; existing 96x74 tab size retained',
        'line_server_acceptance_tested': False, 'files': rows,
    }
    (root/'reports/line-submission-checks.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
    print(f'{ZIP_NAME}: 40 stickers 370x320, main 240x240, tab 96x74; all 42 PNG/RGBA/transparent; {target.stat().st_size} bytes')
    return target


if __name__ == '__main__':
    build_submission()
