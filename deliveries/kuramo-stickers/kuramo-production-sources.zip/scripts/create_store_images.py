#!/usr/bin/env python3
"""Export the user-selected main and tab images without changing stickers."""
from pathlib import Path
import hashlib
import json
import shutil
from PIL import Image, ImageOps
from create_line_submission import inspect_png

ROOT = Path(__file__).resolve().parents[1]


def build_store_images(root=ROOT):
    config = json.loads((root/'assets/store-image-config.json').read_text())
    report = []
    for key in ['main', 'tab']:
        item = config[key]
        size = tuple(item['size'])
        expected = (240, 240) if key == 'main' else (96, 74)
        assert size == expected
        if 'sticker_number' in item:
            folder = 'output/masters' if item.get('include_text') else 'working/illustrations'
            matches = list((root/folder).glob(f'No{item["sticker_number"]:02}*.png'))
            assert len(matches) == 1
            source = matches[0]
        else:
            source = root/item['source_path']
        image = Image.open(source).convert('RGBA')
        bounds = image.getchannel('A').getbbox()
        assert bounds is not None
        image = image.crop(bounds)
        padding = item['padding']
        fitted = ImageOps.contain(image, (size[0]-2*padding, size[1]-2*padding), Image.Resampling.LANCZOS)
        out = Image.new('RGBA', size)
        out.alpha_composite(fitted, ((size[0]-fitted.width)//2, (size[1]-fitted.height)//2))
        target = root/f'output/thumbnails/{key}.png'
        target.parent.mkdir(parents=True, exist_ok=True)
        out.save(target, dpi=(72, 72), optimize=True)
        data = inspect_png(f'{key}.png', target.read_bytes(), size)
        data['source'] = str(source.relative_to(root))
        report.append(data)
        shutil.copy2(target, root/f'output/delivery/{key}.png')
    (root/'reports/store-image-checks.json').write_text(json.dumps({
        'selected_sticker': 36,
        'main': 'Approved No36 sticker including Japanese text and AI robot',
        'tab': 'Face close-up based on the No36 illustration',
        'files': report,
    }, ensure_ascii=False, indent=2))
    print('Store images: No36 main 240x240 and face tab 96x74; PNG/RGBA/transparent verified')


if __name__ == '__main__':
    build_store_images()
