M PLUS Rounded 1c ExtraBold / Copyright 2016 The Rounded M+ Project Authors.
License: SIL Open Font License 1.1, confirmed from embedded name table and official Google Fonts METADATA.pb. Font from google/fonts/ofl/mplusrounded1c. Standard OFL 1.1 text retrieved from google/fonts/ofl/mplus1p/OFL.txt; copyright header reflects the embedded Rounded M+ notice.
