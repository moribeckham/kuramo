# クラモ君・情シスLINEスタンプ40種

ユーザーの制作指示書と、途中で追加された4枚のお手本に従ってNo01から作り直した制作プロジェクトです。

## 内容

- `working/illustrations/`：1枚ずつ独立生成した文字なしイラスト。原寸保存。
- `working/text-svg/`：編集用文字SVG、フォント非依存のアウトラインSVG、配置JSON。
- `output/masters/`：1480×1280pxの透過制作マスター。
- `output/stickers/`：370×320px・RGBA PNG・72dpiの販売候補画像。
- `output/contact-sheets/`：全40枚および10枚ずつの確認一覧。
- `output/delivery/`：目視・技術検査に合格した画像だけの納品パッケージ。
- `prompts/`：各画像の固定セリフ・演出と、実際の生成プロンプト。
- `reports/`：制作状況、目視評価、機械検査、修正履歴。

最終版の実行プロンプトは `NoNN-v2-generation.txt`、画像修正は `NoNN-v2-fix.txt` です。旧スタイルのプロンプトと却下画像は履歴として区別して保存しています。

## 再合成

作業ディレクトリはこのREADMEのフォルダです。既存のPython環境にPillow・NumPy・SciPy・fontToolsが導入済みです。

別のPython環境では `python3 -m pip install -r requirements.txt` で同じバージョンを導入できます。

```sh
python3 scripts/compose_sticker.py
python3 scripts/quality_check.py
python3 scripts/create_contact_sheet.py
python3 scripts/update_status.py
```

特定画像のみなら `python3 scripts/compose_sticker.py --no 9 16` とします。元イラストを上書きせず、文字・白フチ・影を別工程で合成します。

使用書体はM PLUS Rounded 1c ExtraBold（SIL OFL 1.1）。`assets/OFL.txt` と `assets/FONT-NOTICE.md` を参照。SVGを文字として編集する場合は同梱TTFを使用してください。フォントのない環境ではアウトライン版を利用できます。SVG単独は文字レイヤーです。イラスト原本と配置手順は合成スクリプトに保存しています。

## 画像生成と参照

このチャットで提供される `image_gen.imagegen` を各スタンプに1回ずつ独立して使用しました。モデル名・料金情報はツールから公開されていません。外部の有料APIは使用していません。

`generation_manifest.py` は未生成画像のジョブを表示します。Pythonからチャット専用ツールを呼ぶAPIはないため、架空のAPIや認証処理を含めていません。保存済みの画像を再生成せず、各ジョブをチャットのツールで実行し、生成されたPNGを指定先にコピーしてください。

お手本原本は会話に添付されていますがローカルファイルとしては提供されていません。`assets/reference/kuramo-kun-style-reference-v2.png` は追加4見本を参照して作ったNo01を目視確認した派生参照で、原本ではありません。配色JSONもこの派生参照からの推定値です。

最初のスタイルのNo01〜03は `working/rejected/initial-style/` に残してあり、納品には含めません。ユーザーの「作り直し」を受けての履歴です。

## 検査の範囲

メイン文字は制作指示書とユーザーの最新変更指定（assets/text-overrides.json）、サブ文字は指定データとの完全一致を検査します。No36の最新メインは「それAIに聞いたら解決しますよ」です。No39のサブは必ず「（まじかよ…）」です。各画像は生成時の原寸と文字入り一覧の両方で目視し、表情・ミトン・メガネ・マント・留め具・小物・文字の見え方を確認します。点数は制作者による評価で、商業品質を保証する第三者認証ではありません。

LINE公式ガイド `https://creator.line.me/ja/guideline/sticker/` はHTTP 403で取得できませんでした。上記サイズ等は制作上の候補仕様であり、最新の販売要件への適合を断定するものではありません。申請前に公式の最新要件を確認してください。LINEへのアップロード・公開は行っていません。
